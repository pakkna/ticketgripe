<?php if(Session::has('flashMessageSuccess')): ?>
    <div class="alert alert-success alert-dismissible text-center" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
        <?php echo e(Session::get('flashMessageSuccess')); ?>

    </div>
<?php endif; ?>

<?php if(Session::has('flashMessageAlert')): ?>
    <div class="alert alert-danger alert-dismissible text-center" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
        <?php echo e(Session::get('flashMessageAlert')); ?>

    </div>
<?php endif; ?>

<?php if(Session::has('flashMessageWarning')): ?>
    <div class="alert alert-warning alert-dismissible text-center" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
        <?php echo e(Session::get('flashMessageWarning')); ?>

    </div>
<?php endif; ?>

<?php if(Session::has('flashMessageDanger')): ?>
    <div class="alert alert-danger alert-dismissible text-center" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
        <?php echo e(Session::get('flashMessageDanger')); ?>

    </div>
<?php endif; ?>