//# sourceMappingURL=form-fields.js.map
$(function() {
    $(document).on("click", ".option-up", function(a) {
        console.debug("Option up");
        a.preventDefault();
        a = $(this).closest("tr");
        var b = a.prev("tr");
        0 !== b.length && a.insertBefore(b);
        reIndexOptionNames();
        return !1
    });
    
    $(document).on("click", ".option-down", function(aa) {
        console.debug("Option down");
        aa.preventDefault();
        aa = $(this).closest("tr");
        var b = aa.next("tr");
        0 !== b.length && aa.insertAfter(b);
        reIndexOptionNames();
        return !1
    });

    $(document).on("click", ".option-delete", function(a) {
        $(this).closest("tr").remove();
        reIndexOptionNames();
        return !1
    })
});

function reIndexOptionNames() {
    var a = $("#availableOptionTable tr");
    // console.debug(a);
    // console.debug(a.size());
    a.each(function(a) {
        console.log("Index: " + a);
        $(this).find("input[name*='id']").attr("name", "choices[" + a + "].id");
        $(this).find("input[name*='label']").attr("name", "choices[" + a + "].label")
    })
}

function addOption() {
    console.debug("Adding Available Option");
    var a = $("<tr/>"),
        b = $("<input/>").attr("type", "text").attr("name", "choices[].label").addClass('payment-input cus-input'),
        b = $("<td/>").append(b),
        c = $("<button/>").addClass("btn btn-xs btn-default btn-bg-custom option-up").append($("<i/>").addClass("fas fa-arrow-up")),
        d = $("<button/>").addClass("btn btn-xs btn-default btn-bg-custom option-down").append($("<i/>").addClass("fas fa-arrow-down")),
        e = $("<button/>").addClass("btn btn-xs btn-danger option-delete").append($("<i/>").addClass("fas fa-trash")),
        c = $("<td/>").append(c).append("&nbsp;").append(d).append("&nbsp;").append(e);
    $("#availableOptionTable").append(a.append(b).append(c));
    reIndexOptionNames()
};