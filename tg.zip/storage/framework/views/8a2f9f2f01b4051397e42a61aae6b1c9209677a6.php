Hi <?php echo e($data['name']); ?>,<br>
Welcome to Ticket Gripe. <br>
You have purchased ticket for the event <strong><?php echo e($data['event_title']); ?></strong>.<br>
You can download or print your ticket from this link <a href="https://ticketgripe.com/ticket-view/<?php echo e($data['tran_id']); ?>/<?php echo e($data['event_id']); ?>/<?php echo e($data['ticket_id']); ?>/<?php echo e($data['random_number']); ?>">https://ticketgripe.com/ticket-view/<?php echo e($data['tran_id']); ?>/<?php echo e($data['event_id']); ?>/<?php echo e($data['ticket_id']); ?>/<?php echo e($data['random_number']); ?></a> <br>
After the event expires, you can no longer access this ticket. <br>
<br> For further queries email at: <br> support@ticketgripe.com
<br><br>
Regards, <br>
Team Ticket Gripe<br>
Website: www.ticketgripe.com